<!-- Google Tag Manager (noscript) -->
    <noscript
      ><iframe
        src="https://www.googletagmanager.com/ns.html?id=GTM-WRD2W4Q"
        height="0"
        width="0"
        style="display: none; visibility: hidden"
      ></iframe
    ></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <div class="cursor"></div>

    <nav class="sub-nav">
      <ul class="anchor-links">
        <li class="logo">
          <a href="/">
            <img src="/assets/Samata Health_logo.svg" alt="logo" />
          </a>
        </li>
        <li class="products active">Our Products</li>
        <li class="platform">Our Platform</li>
        <li class="numbers">By the Numbers</li>
        <li class="how-it-works">How it Works</li>
        <li class="testimonials">Happy Clients</li>
      </ul>
      <ul class="btn-wrapper">
        <li>
          <a href="/request-a-demo" class="btn white-bg">Request a Demo</a>
        </li>
        <li>
          <a
            href="https://app.samatahealth.com/search-options"
            class="btn white-bg"
            >Find a Therapist</a
          >
        </li>
      </ul>
    </nav>
    <section id="banner">
      <nav class="banner-nav">
        <ul>
          <li class="logo">
            <a href="/">
              <img src="/assets/Samata Health_logo.svg" alt="logo" />
            </a>
          </li>
          <li>
            <a href="https://samatahealth.zendesk.com/hc/en-us"
              >Support Center</a
            >
          </li>
          <li><a href="/contact">Contact Us</a></li>
          <!-- <li>
            <a href="https://go.samatahealth.com/blog/">Blog</a>
          </li> -->
        </ul>
        <ul class="btn-wrapper">
          <li>
            <a href="/request-a-demo" class="btn white-bg">Request a Demo</a>
          </li>
          <li>
            <a
              href="https://app.samatahealth.com/search-options"
              class="btn white-bg"
              >Find a Therapist</a
            >
          </li>
        </ul>
        <div class="nav-toggle">
          <div class="line"></div>
          <div class="line"></div>
          <div class="line"></div>
        </div>
      </nav>
      <div class="container">
        <div class="major">
          <h1>Progressive Mental Health Care at Your Fingertips</h1>
          <aside>
            <a href="/request-a-demo" class="btn">Request a Demo</a>
            <a href="#platform" class="has-play-btn"> See How it Works</a>
          </aside>
        </div>

        <div class="minor">
          <div class="img-wrapper">
            <img src="/assets/Phone.png" alt="app" />
          </div>
          <aside class="b1">
            <img src="/assets/Block 1.png" alt="app" />
          </aside>
          <aside class="b2">
            <img src="/assets/Block 2.png" alt="app" />
          </aside>
          <aside class="b3">
            <img src="/assets/Block 3.png" alt="app" />
          </aside>
          <p class="blue-text">Real Therapists Featured!</p>
        </div>
      </div>
    </section>
    <section id="products">
      <h2 class="has-underline center">Our Products</h2>
      <div class="container">
        <div class="col">
          <div class="img-wrapper">
            <img src="/assets/Group 143.svg" alt="illustration" />
          </div>
          <div class="content">
            <h3>For Employers</h3>
            <p>Our Premium, Progressive Employee Mental Health Benefit</p>
          </div>
          <a href="#" class="btn" target="employers">Learn More</a>
        </div>
        <div class="col">
          <div class="img-wrapper">
            <img src="/assets/Group 144.svg" alt="illustration" />
          </div>
          <div class="content">
            <h3>For Individuals</h3>
            <p>Our Public-Facing Platform for Individual Therapy-Seekers</p>
          </div>
          <a href="#" class="btn" target="individuals">Learn More</a>
        </div>
      </div>
    </section>
    <section id="platform">
      <h2 class="center">Our Platform</h2>
      <div class="container">
        <div class="v-line"></div>
        <p class="blue-text">Watch the Video!</p>
        <img class="caret-down" src="/assets/caret-down.svg" alt="caret-down" />
        <div class="video-wrapper">
          <div class="video-overlay">
            <img src="/assets/video-play-btn.png" alt="video-play-btn" />
          </div>
          <video
            controls
            poster="/assets/Final Platform Demo.jpg"
            src="/assets/Final Platform Demo.mp4"
          ></video>
        </div>
      </div>
      <div class="slider">
        <header>
          <div class="v-line"></div>
          <h3>
            <span class="active">Start.</span> <span>Match.</span>
            <span>Book.</span>
          </h3>
        </header>

        <div class="slides">
          <div class="slide">
            <div class="row img">
              <h1 class="slide-num">1</h1>
              <div class="img-wrapper">
                <img src="/assets/Start.png" alt="slide-1" />
              </div>
            </div>
            <div class="row content">
              <div class="icon">
                <img src="/assets/Start-icon.svg" alt="start-icon" />
              </div>
              <h3>Start</h3>
              <h5>
                To get started, tell us what you’re looking for in a therapist.
                Enter your preferences for clinical specialties, cultural
                competencies and more!
              </h5>
            </div>
          </div>
          <div class="slide">
            <div class="row img">
              <h1 class="slide-num">2</h1>
              <div class="img-wrapper">
                <img src="/assets/Match.PNG" alt="slide-2" />
              </div>
            </div>
            <div class="row content">
              <div class="icon">
                <img src="/assets/Match-icon.svg" alt="match-icon" />
              </div>
              <h3>Match</h3>
              <h5>
                Based on your preferences, our matching algorithm finds the best
                therapists tailored to fit your needs.
              </h5>
            </div>
          </div>
          <div class="slide">
            <div class="row img">
              <h1 class="slide-num">3</h1>
              <div class="img-wrapper">
                <img src="/assets/Book.PNG" alt="slide-3" />
              </div>
            </div>
            <div class="row content">
              <div class="icon">
                <img src="/assets/Book-icon.svg" alt="book-icon" />
              </div>
              <h3>Book</h3>
              <h5>
                Book a therapy session right on our platform. No phone calls
                necessary!
              </h5>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section id="numbers">
      <div class="minor">
        <p class="blue-text">Our Platform</p>
        <h2>By the Numbers</h2>
        <div class="content">
          <div class="row">
            <div class="icon">
              <img src="/assets/90-Icon.svg" alt="90-icon" />
            </div>
            <div class="col">
              <h2 data-count="90" class="counter">00</h2>
              <p>Percent</p>
            </div>
            <div class="col">
              <p>
                Thanks to our matching algorithm,
                <span class="blue-text">over 90%</span> of people book follow-up
                sessions with their therapist on our platform.
              </p>
            </div>
          </div>
          <div class="row">
            <div class="icon">
              <img src="/assets/50-Icon.svg" alt="50-icon" />
            </div>
            <div class="col">
              <h2 data-count="50" class="counter">00</h2>
              <p>Percent</p>
            </div>
            <div class="col">
              <p>
                Therapists on our platform agree to see Samata Health clients
                for <span class="blue-text">less than half</span> the average
                cost per session in your city!
              </p>
            </div>
          </div>
          <div class="row">
            <div class="icon">
              <img src="/assets/3Min-Icon.svg" alt="3min-icon" />
            </div>
            <div class="col">
              <h2>0<span data-count="3" class="counter">0</span></h2>
              <p>Minutes</p>
            </div>
            <div class="col">
              <p>
                <span class="blue-text">Average amount of time</span> it takes
                to schedule a therapy session on our digital platform.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div class="major">
        <div class="img-wrapper">
          <img
            src="/assets/woman-smiling-at-dog.png"
            alt="woman-smiling-at-dog"
          />
        </div>
        <aside>
          <figure>
            <img
              src="/assets/two-people-talking.png"
              alt="two-people-talking"
            />
          </figure>
          <figure>
            <img
              src="/assets/woman-talking-on-phone-walking.png"
              alt="woman-talking-on-phone-walking"
            />
          </figure>
        </aside>
      </div>
    </section>

    <section id="how-it-works">
      <header>
        <h2>How it Works</h2>
        <ul class="toggle">
          <li class="has-underline"></li>
          <li class="employers active"><h4>For Employers</h4></li>
          <li class="therapists"><h4>For Therapists</h4></li>
          <li class="individuals"><h4>For Individuals</h4></li>
        </ul>
      </header>
      <div class="container">
        <div class="minor">
          <div class="img-wrapper">
            <div class="screen"></div>
            <img
              class="img__employers"
              src="/assets/meeting-people-smiling.png"
              alt="meeting-people-smiling"
            />
            <img
              class="img__therapists"
              src="/assets/woman-crossing-arms-smiling.png"
              alt="woman-crossing-arms-smiling"
            />
            <img
              class="img__individuals"
              src="/assets/woman-glasses-smiling.png"
              alt="woman-glasses-smiling"
            />
            <aside>
              <div class="aside__employers">
                <h4 class="white-text">
                  Say Hello To Your Happier, Healthier And More Productive
                  Workforce
                </h4>
                <a href="/request-a-demo" class="btn white-bg"
                  >Request a Demo</a
                >
              </div>
              <div class="aside__therapists">
                <h4 class="white-text">
                  You Support Your Clients.<br />
                  We’ll Support You!
                </h4>
                <a href="/apply-now" class="btn white-bg">Apply Now</a>
              </div>
              <div class="aside__individuals">
                <h4 class="white-text">Start Feeling Better Today!</h4>
                <a
                  href="https://app.samatahealth.com/search-options"
                  class="btn white-bg"
                  >Find a Therapist</a
                >
              </div>
            </aside>
          </div>
        </div>

        <div class="major">
          <div class="major__employers">
            <div class="row header">
              <div class="icon">
                <img src="/assets/Icon-WhyInvest.svg" alt="icon" />
              </div>
              <h3>Why Invest in Employee Mental Health</h3>
            </div>
            <div class="row">
              <div class="icon">
                <img src="/assets/checkmark.svg" alt="icon" />
              </div>
              <div class="col">
                <h4>Health Insurance ≠ Mental Health Care</h4>
                <p>
                  60% of U.S. employees who sought mental health care last year
                  had to pay out of pocket because their existing benefits
                  (health insurance and traditional EAPs) were inadequate.
                </p>
              </div>
            </div>
            <div class="row">
              <div class="icon">
                <img src="/assets/checkmark.svg" alt="icon" />
              </div>
              <div class="col">
                <h4>Investing In Your People Brings Real Returns</h4>
                <p>
                  Employers see an average 4:1 return on every dollar they
                  invest in employee mental health.
                </p>
              </div>
            </div>
            <div class="line"></div>
            <div class="row header">
              <div class="icon">
                <img src="/assets/icon-bullhorn.svg" alt="icon" />
              </div>
              <h3>Why Work With Us</h3>
            </div>
            <div class="row">
              <div class="icon">
                <img src="/assets/checkmark.svg" alt="icon" />
              </div>
              <div class="col">
                <h4>5x Higher Employee Engagement</h4>
                <p>
                  15-20% of employees use our benefit in just the first few
                  months, vs. 3-4% average engagement for traditional EAPs over
                  a full year.
                </p>
              </div>
            </div>
            <div class="row">
              <div class="icon">
                <img src="/assets/checkmark.svg" alt="icon" />
              </div>
              <div class="col">
                <h4>Premium Care at Affordable, Monthly Rates</h4>
                <p>
                  With Samata Health, you'll choose how many therapy sessions to
                  cover for your employees, and we'll charge you monthly—only
                  for therapy sessions your employees actually use. Plus, our
                  licensed therapists all agree to treat Samata Health clients
                  for less than half the average cost per therapy session.
                </p>
              </div>
            </div>
          </div>

          <div class="major__therapists">
            <div class="row header">
              <div class="icon">
                <img src="/assets/icon-bullhorn.svg" alt="icon" />
              </div>
              <h3>Why Work With Us</h3>
            </div>
            <div class="row">
              <div class="icon">
                <img src="/assets/checkmark.svg" alt="icon" />
              </div>
              <div class="col">
                <h4>Access To Great New Clients</h4>
                <p>
                  Thanks to our tailored matching process, we guarantee your
                  Samata Health clients will be some of your best.
                </p>
              </div>
            </div>
            <div class="row">
              <div class="icon">
                <img src="/assets/checkmark.svg" alt="icon" />
              </div>
              <div class="col">
                <h4>Stay In Control Of Your Practice</h4>
                <p>
                  You know best how to run your practice. We’ll never tell you
                  which clients to take on or how to treat them.
                </p>
              </div>
            </div>
            <div class="row">
              <div class="icon">
                <img src="/assets/checkmark.svg" alt="icon" />
              </div>
              <div class="col">
                <h4>Higher Rates And Faster Payments</h4>
                <p>
                  Charge up to $125 for 45-minute therapy sessions and get paid
                  in just a few days. No claims, no hassle!
                </p>
              </div>
            </div>
          </div>

          <div class="major__individuals">
            <div class="row header">
              <div class="icon">
                <img src="/assets/icon-bullhorn.svg" alt="icon" />
              </div>
              <h3>Why Work With Us</h3>
            </div>
            <div class="row">
              <div class="icon">
                <img src="/assets/checkmark.svg" alt="icon" />
              </div>
              <div class="col">
                <h4>Affordable</h4>
                <p>
                  High-quality therapy shouldn’t be a luxury. Therapists on our
                  platform all agree to see Samata Health clients for less than
                  half the average cost per therapy session in New York City!
                </p>
              </div>
            </div>
            <div class="row">
              <div class="icon">
                <img src="/assets/checkmark.svg" alt="icon" />
              </div>
              <div class="col">
                <h4>Digital</h4>
                <p>
                  Bye, phone tag! On our digital platform, you can view
                  therapist profiles, chat with therapists in our secure
                  messaging portal and book sessions instantly.
                </p>
              </div>
            </div>
            <div class="row">
              <div class="icon">
                <img src="/assets/checkmark.svg" alt="icon" />
              </div>
              <div class="col">
                <h4>Diverse</h4>
                <p>
                  Looking for a therapist who identifies as male? Latinx?
                  Jewish? Our team of experienced, licensed therapists is
                  diverse in every way. Just enter your preferences and we’ll
                  automatically recommend the best matches for you!
                </p>
              </div>
            </div>
          </div>
        </div>

        <div class="steps">
          <header>
            <div class="icon">
              <img src="/assets/HowitWorks-Icon.svg" alt="how-it-works" />
            </div>
            <div class="title">
              <h3>How it Works</h3>
              <p>
                <i>For Employers</i>
              </p>
            </div>
          </header>

          <div class="row-container init__employers">
            <div class="row employers">
              <div class="col">
                <div class="inner">
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Employee.svg"
                      alt="HowItWorks-Employee"
                    />
                  </div>
                  <div class="arrow">
                    <img src="/assets/blue-arrow.svg" alt="arrow-icon" />
                  </div>
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Therapist.svg"
                      alt="HowItWorks-Therapist"
                    />
                  </div>
                </div>
                <h1 class="blue-text">1</h1>
                <h4>
                  Employee selects, schedules<br />
                  and meets with a therapist.
                </h4>
              </div>
              <div class="col">
                <div class="inner">
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Samata.svg"
                      alt="HowItWorks-Samata"
                    />
                  </div>
                  <div class="arrow">
                    <img src="/assets/blue-arrow.svg" alt="arrow-icon" />
                  </div>
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Therapist.svg"
                      alt="HowItWorks-Therapist"
                    />
                  </div>
                </div>
                <h1 class="blue-text">2</h1>
                <h4>Samata Health<br />pays the therapist</h4>
              </div>
              <div class="col">
                <div class="inner">
                  <div class="icon">
                    <img
                      src="/assets/Icon-Employer.svg"
                      alt="HowItWorks-Employer"
                    />
                  </div>
                  <div class="arrow">
                    <img src="/assets/blue-arrow.svg" alt="arrow-icon" />
                  </div>
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Samata.svg"
                      alt="HowItWorks-Samata"
                    />
                  </div>
                </div>
                <h1 class="blue-text">3</h1>
                <h4>
                  Employer pays<br />
                  Samata Health
                </h4>
              </div>
            </div>

            <div class="row therapists">
              <div class="col">
                <div class="inner">
                  <div class="icon">
                    <img
                      src="/assets/Icon-Client.svg"
                      alt="HowItWorks-Client"
                    />
                  </div>
                  <div class="arrow">
                    <img src="/assets/blue-arrow.svg" alt="arrow-icon" />
                  </div>
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Therapist.svg"
                      alt="HowItWorks-Therapist"
                    />
                  </div>
                </div>
                <h1 class="blue-text">1</h1>
                <h4>Client matches with therapist</h4>
              </div>
              <div class="col">
                <div class="inner">
                  <div class="icon lg">
                    <img
                      src="/assets/ClientEmployer-Icon.svg"
                      alt="HowItWorks-ClientEmployer"
                    />
                  </div>
                  <div class="arrow">
                    <img src="/assets/blue-arrow.svg" alt="arrow-icon" />
                  </div>
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Therapist.svg"
                      alt="HowItWorks-Therapist"
                    />
                  </div>
                </div>
                <h1 class="blue-text">2</h1>
                <h4>Client (or their employer)<br />pays Samata Health</h4>
              </div>
              <div class="col">
                <div class="inner">
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Samata.svg"
                      alt="HowItWorks-Samata"
                    />
                  </div>
                  <div class="arrow">
                    <img src="/assets/blue-arrow.svg" alt="arrow-icon" />
                  </div>
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Therapist.svg"
                      alt="HowItWorks-Therapist"
                    />
                  </div>
                </div>
                <h1 class="blue-text">3</h1>
                <h4>
                  Samata Health<br />
                  pays therapist
                </h4>
              </div>
            </div>

            <div class="row individuals">
              <div class="col">
                <div class="inner">
                  <div class="icon">
                    <img
                      src="/assets/Icon-Client.svg"
                      alt="HowItWorks-Client"
                    />
                  </div>
                  <div class="arrow">
                    <img src="/assets/blue-arrow.svg" alt="arrow-icon" />
                  </div>
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Therapist.svg"
                      alt="HowItWorks-Therapist"
                    />
                  </div>
                </div>
                <h1 class="blue-text">1</h1>
                <h4>Select a therapist</h4>
              </div>
              <div class="col">
                <div class="inner">
                  <div class="icon">
                    <img
                      src="/assets/Icon-Client.svg"
                      alt="HowItWorks-Client"
                    />
                  </div>
                  <div class="arrow">
                    <img src="/assets/blue-arrow.svg" alt="arrow-icon" />
                  </div>
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Samata.svg"
                      alt="HowItWorks-Samata"
                    />
                  </div>
                </div>
                <h1 class="blue-text">2</h1>
                <h4>
                  Pay on our platform when you<br />book your therapy session*
                </h4>
              </div>
              <div class="col">
                <div class="inner">
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Samata.svg"
                      alt="HowItWorks-Samata"
                    />
                  </div>
                  <div class="arrow">
                    <img src="/assets/blue-arrow.svg" alt="arrow-icon" />
                  </div>
                  <div class="icon">
                    <img
                      src="/assets/HowItWorks-Therapist.svg"
                      alt="HowItWorks-Therapist"
                    />
                  </div>
                </div>
                <h1 class="blue-text">3</h1>
                <h4>
                  Samata Health pays<br />
                  your therapist!
                </h4>
              </div>
            </div>
            <p class="note">
              *Employer-sponsored sessions are completely free for individuals
              using our employee benefit!
            </p>
          </div>
        </div>
      </div>
      <div id="calculator">
        <!-- <hr /> -->
        <div class="container">
          <h3>Mental Health Cost Calculator for Employers</h3>
          <div class="tracker">
            <div class="bar">
              <div class="bg"></div>
              <div class="track">
                <h3 class="num">10</h3>
                <p>Number of Employees</p>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col">
              <h2>$<span class="val-1">50,550</span></h2>
              <h5>Cost of Poor Employee Mental Health</h5>
              <p>
                <i
                  >(Accounts for turnover, absenteeism, lost productivity and
                  higher insurance premiums.)</i
                >
              </p>
            </div>
            <!-- <div class="col">
              <h5 class="val-2">0</h5>
              <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Fuga,
                doloremque!
              </p>
            </div>
            <div class="col">
              <h5 class="val-3">0</h5>
              <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Fuga,
                doloremque!
              </p>
            </div> -->
          </div>
          <p class="sources">
            Sources:
            <a
              href="https://www2.deloitte.com/content/dam/Deloitte/uk/Documents/consultancy/deloitte-uk-mental-health-and-employers.pdf"
              target="_blank"
              rel="noopener noreferrer"
              >Deloitte</a
            >
            and
            <a
              href="https://sapienlabs.org/mentalog/the-cost-of-poor-mental-health-in-the-workplace/"
              target="_blank"
              rel="noopener noreferrer"
              >Sapien Labs</a
            >
          </p>
        </div>
      </div>
    </section>

    <section id="testimonials">
      <header class="navy">
        <div class="wrap">
          <div class="icon">
            <img
              class="navy-icon"
              src="/assets/Testimonials-navy.svg"
              alt="clients-icon"
            />
            <img
              class="green-icon"
              src="/assets/Testimonials-green.svg"
              alt="clients-icon"
            />
            <img
              class="blue-icon"
              src="/assets/Testimonials-blue.svg"
              alt="clients-icon"
            />
          </div>
          <h2>Our Happy Clients</h2>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="93.045"
            height="10.535"
            viewBox="0 0 93.045 10.535"
          >
            <defs>
              <style>
                .a {
                  fill: none;
                  stroke: inherit;
                  stroke-miterlimit: 10;
                  stroke-width: 3px;
                }
              </style>
            </defs>
            <g transform="translate(0 1.5)">
              <path
                class="a"
                d="M852.938-251.888c11.63,0,11.63-7.535,23.26-7.535s11.63,7.535,23.261,7.535,11.631-7.535,23.262-7.535,11.631,7.535,23.262,7.535"
                transform="translate(-852.938 259.423)"
              />
            </g>
          </svg>
        </div>
      </header>
      <div class="slider">
        <div class="slide active one">
          <div class="col">
            <div class="logo">
              <img
                src="/assets/Blue Graphika Logo (2019).png"
                alt="graphika_logo"
              />
            </div>
            <p>Sarah Braver, <br />VP of People, Graphika</p>
          </div>
          <div class="col content">
            <h4>
              “As COVID-19 hit and Graphika instituted remote work, we saw it as
              even more critical to put a premium on employee wellness, which
              encompasses mental health. We’re working with Samata Health today
              to provide our employees the option to leverage one-on-one
              therapist sessions and team talk therapy sessions. With Samata,
              we’ve been able to support our employees and create a more
              inclusive space where mental healthcare is normalized.”
            </h4>
          </div>
        </div>
        <div class="slide next-slide two">
          <div class="col">
            <div class="logo">
              <img src="/assets/alloy_logo__final_.png" alt="alloy_logo" />
            </div>
            <p>
              Alloy People<br />
              Operations Team
            </p>
          </div>
          <div class="col content">
            <h4>
              “Samata Health has been a fantastic partner in supporting our
              team!”
            </h4>
          </div>
        </div>
        <div class="slide three is-visible">
          <div class="col">
            <div class="logo rounded">
              <img src="/assets/Raymond Batista.jpeg" alt="Raymond Batista" />
            </div>
            <p>
              Raymond Batista,<br />
              Licensed Clinical Social Worker
            </p>
          </div>
          <div class="col content">
            <h4>
              "It's great to be part of a platform that helps clients access
              affordable care while taking away the stress of being paneled
              [with insurance companies] for therapists!"
            </h4>
          </div>
        </div>
        <!-- <div class="slide four">
          <div class="col">
            <div class="logo rounded">
              <img src="/assets/daniel.jpg" alt="daniel" />
            </div>
            <p>Daniel, Brooklyn</p>
          </div>
          <div class="col content">
            <h4>
              “I was so tired of being put on wait lists for in-network
              therapists. It was really easy to book a session on Samata's
              platform, and it's awesome that their therapists all have
              transparent, affordable rates.”
            </h4>
          </div>
        </div> -->

        <div class="nav-bar">
          <div class="major">
            <p><span class="num">01</span>/<span class="total">03</span></p>
          </div>
          <div class="minor next">
            <p>Next</p>
            <div class="icon">
              <img src="/assets/Arrow-Icon.svg" alt="arrow-icon" />
              <img
                class="hover"
                src="/assets/Arrow-Icon-hover.svg"
                alt="arrow-icon"
              />
            </div>
          </div>
        </div>
      </div>
    </section>

    <footer class="home">
      <div class="top">
        <div class="container">
          <header>
            <div class="img-wrapper">
              <img src="/assets/subscribe-icon.svg" alt="subscribe-icon" />
            </div>
            <div class="col">
              <h2>Join the list</h2>
              <h5>
                We'll send occasional product<br />
                updates and special offers.
              </h5>
              <!-- <br />
              <h5>
                Feel free to check out our
                <a href="https://go.samatahealth.com/blog/">blog</a>!
              </h5> -->
            </div>
          </header>
          <div class="form-wrapper">
            <script src="https://f.convertkit.com/ckjs/ck.5.js"></script>
            <form
              action="https://app.convertkit.com/forms/1653666/subscriptions"
              class="seva-form formkit-form"
              method="post"
              data-sv-form="1653666"
              data-uid="41f2bddb61"
              data-format="inline"
              data-version="5"
              data-options='{"settings":{"after_subscribe":{"action":"message","success_message":"Success! Now check your email to confirm your subscription.","redirect_url":""},"analytics":{"google":null,"facebook":null,"segment":null,"pinterest":null},"modal":{"trigger":"timer","scroll_percentage":null,"timer":5,"devices":"all","show_once_every":15},"powered_by":{"show":true,"url":"https://convertkit.com?utm_source=dynamic&amp;utm_medium=referral&amp;utm_campaign=poweredby&amp;utm_content=form"},"recaptcha":{"enabled":false},"return_visitor":{"action":"show","custom_content":""},"slide_in":{"display_in":"bottom_right","trigger":"timer","scroll_percentage":null,"timer":5,"devices":"all","show_once_every":15},"sticky_bar":{"display_in":"top","trigger":"timer","scroll_percentage":null,"timer":5,"devices":"all","show_once_every":15}},"version":"5"}'
              min-width="400 500 600 700 800"
            >
              <div data-style="clean">
                <ul
                  class="formkit-alert formkit-alert-error"
                  data-element="errors"
                  data-group="alert"
                ></ul>
                <div
                  data-element="fields"
                  data-stacked="false"
                  class="seva-fields formkit-fields"
                >
                  <div class="formkit-field">
                    <input
                      class="formkit-input"
                      aria-label="First Name"
                      name="fields[first_name]"
                      required=""
                      placeholder="First Name"
                      type="text"
                    />
                  </div>
                  <div class="formkit-field">
                    <input
                      class="formkit-input"
                      name="email_address"
                      aria-label="Email Address"
                      placeholder="Email Address"
                      required=""
                      type="email"
                    />
                  </div>
                  <button
                    data-element="submit"
                    class="formkit-submit formkit-submit btn"
                    style="margin-top: 30px"
                  >
                    <div class="formkit-spinner">
                      <div></div>
                      <div></div>
                      <div></div>
                    </div>
                    <span>Sign Up</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
          <aside>
            <p class="legal">
              If you are in a life-threatening situation, please get immediate
              help by calling the 24-hour National Suicide Prevention Lifeline
              at 1 (800) 273-8255, call 911, or go to your nearest emergency
              room. Please do not use Samata Health’s platform as it is not
              equipped with first responders who can immediately provide help
              and safety.
            </p>
            <ul class="col">
              <p>Employers</p>
              <li>
                <a href="/request-a-demo">Request a Demo</a>
              </li>
              <li><a href="/contact#employers">Contact Us</a></li>
            </ul>
            <ul class="col">
              <p>Therapists</p>
              <li><a href="/apply-now">Apply</a></li>
              <li><a href="/contact#therapists">Contact Us</a></li>
            </ul>
            <ul class="col">
              <p>Therapy-Seekers</p>
              <li>
                <a href="https://app.samatahealth.com/search-options"
                  >Find a Therapist</a
                >
              </li>
              <li><a href="/contact#individuals">Contact Us</a></li>
            </ul>
            <ul class="col">
              <p>Resources</p>
              <li>
                <a href="https://samatahealth.zendesk.com/hc/en-us"
                  >Support Center</a
                >
              </li>
              <li>
                <a
                  data-formkit-toggle="06055a3632"
                  href="https://samatahealth.ck.page/06055a3632"
                  >Newsletter</a
                >
              </li>
              <!-- <li>
                <a href="https://go.samatahealth.com/blog/">Blog</a>
              </li> -->
            </ul>
            <ul class="col media">
              <p>Find Us On</p>
              <li>
                <a
                  href="https://www.linkedin.com/company/samatahealth/"
                  target="_blank"
                  rel="noopener noreferrer"
                  ><img src="/assets/LinkedIn-Icon.svg" alt="LinkedIn-Icon" />
                  <img
                    class="hover"
                    src="/assets/LinkedIn-Icon-navy.svg"
                    alt="LinkedIn-Icon"
                  />
                  LinkedIn</a
                >
              </li>
              <li>
                <a
                  href="https://www.facebook.com/samatahealth/"
                  target="_blank"
                  rel="noopener noreferrer"
                  ><img src="/assets/Facebook-Icon.svg" alt="Facebook-Icon" />
                  <img
                    class="hover"
                    src="/assets/FB-icon-navy.svg"
                    alt="Facebook-Icon"
                  />
                  Facebook</a
                >
              </li>
              <li>
                <a
                  href="https://www.instagram.com/samatahealth/"
                  target="_blank"
                  rel="noopener noreferrer"
                  ><img src="/assets/Instagram-Icon.svg" alt="Instagram-Icon" />
                  <img
                    class="hover"
                    src="/assets/Instagram-icon-navy.svg"
                    alt="Instagram-Icon"
                  />
                  Instagram</a
                >
              </li>
            </ul>
          </aside>
        </div>
      </div>
      <div class="bottom">
        <div class="container">
          <p>Copyright © 2020 Samata Health. All Rights Reserved</p>
          <div class="links">
            <a href="mailto:team@samatahealth.com">Email Us</a>
            <a href="/privacy-policy">Privacy Policy</a>
            <a
              target="_blank"
              rel="noopener noreferrer"
              href="https://app.termly.io/document/cookie-policy/f6743683-5359-4355-9648-7b7bf0d0a28c"
              >Cookie Policy</a
            >
            <a
              target="_blank"
              rel="noopener noreferrer"
              href="https://app.termly.io/document/terms-of-use-for-online-marketplace/d955c6fe-92c6-4a4f-a8eb-902e03c6f768"
              >Terms of Use</a
            >
          </div>
        </div>
      </div>
    </footer>
    <script src="https://f.convertkit.com/ckjs/ck.5.js"></script>
    <form
      action="https://app.convertkit.com/forms/1163245/subscriptions"
      style="background-color: rgb(255, 255, 255); border-radius: 4px"
      class="seva-form formkit-form"
      method="post"
      data-sv-form="1163245"
      data-uid="06055a3632"
      data-format="modal"
      data-version="5"
      data-options='{"settings":{"after_subscribe":{"action":"message","success_message":"Success! Now check your email to confirm your subscription.","redirect_url":""},"analytics":{"google":null,"facebook":null,"segment":null,"pinterest":null},"modal":{"trigger":"timer","scroll_percentage":null,"timer":"10","devices":"all","show_once_every":"1"},"powered_by":{"show":false,"url":"https://convertkit.com?utm_source=dynamic&amp;utm_medium=referral&amp;utm_campaign=poweredby&amp;utm_content=form"},"recaptcha":{"enabled":false},"return_visitor":{"action":"hide","custom_content":""},"slide_in":{"display_in":"bottom_right","trigger":"timer","scroll_percentage":null,"timer":5,"devices":"all","show_once_every":15},"sticky_bar":{"display_in":"top","trigger":"timer","scroll_percentage":null,"timer":5,"devices":"all","show_once_every":15}},"version":"5"}'
      min-width="400 500 600 700 800"
    >
      <div data-style="full">
        <div
          data-element="column"
          style="
            background-image: url('https://embed.filekitcdn.com/e/jfukhmt2Q44dgzGF3uHaRX/kLmSRRbHtM7YsdLBwreyp5');
            background-color: rgb(16, 16, 16);
          "
          class="formkit-background"
        ></div>
        <div data-element="column" class="formkit-column">
          <div
            class="formkit-header"
            style="color: rgb(77, 77, 77); font-size: 26px; font-weight: 700"
            data-element="header"
          >
            <h1>Get the latest news from Samata Health!</h1>
          </div>
          <ul
            class="formkit-alert formkit-alert-error"
            data-element="errors"
            data-group="alert"
          ></ul>
          <div data-element="fields" class="seva-fields formkit-fields">
            <div class="formkit-field">
              <input
                class="formkit-input"
                aria-label="First Name"
                style="
                  color: rgb(0, 0, 0);
                  border-color: rgb(227, 227, 227);
                  border-radius: 4px;
                  font-weight: 400;
                "
                name="fields[first_name]"
                placeholder="First Name"
                type="text"
              />
            </div>
            <div class="formkit-field">
              <input
                class="formkit-input"
                name="email_address"
                style="
                  color: rgb(0, 0, 0);
                  border-color: rgb(227, 227, 227);
                  border-radius: 4px;
                  font-weight: 400;
                "
                aria-label="Your email address"
                placeholder="Your email address"
                required=""
                type="email"
              />
            </div>
            <button
              data-element="submit"
              class="formkit-submit formkit-submit"
              style="
                color: rgb(255, 255, 255);
                background-color: rgb(28, 177, 176);
                border-radius: 4px;
                font-weight: 700;
              "
            >
              <div class="formkit-spinner">
                <div></div>
                <div></div>
                <div></div>
              </div>
              <span>Subscribe</span>
            </button>
          </div>
          <div
            class="formkit-disclaimer"
            style="color: rgb(139, 139, 139); font-size: 13px"
            data-element="disclaimer"
          >
            We respect your privacy. Unsubscribe at anytime.
          </div>
        </div>
      </div>
    </form>
  </body>